/*------------------------------------------------------------------------------
Search for the string: COMMA,DELIMITED,OUT_PAYMENT_IDS

Replace all instances of it with your OUT_PAYMENT_ID values, comma-delimted
(e.g. 3364461871,3364463588,3364467228,3364956470,3364957379,3364957884)

--------------------------------------------------------------------------------
WHAT IF I DON'T ALREADY HAVE THE OUT_PAYMENT_ID?

GET ac_pmnt_interface_out data for Instalment # X on Policy # Y
Only if you don't already have the OUT_PAYMENT_ID information.

It provides a lot of information so you can be confident in what you have 
had returned, but all you need is the OUT_PAYMENT_ID for use in the queries 
that follow below.

Example Output (partial):
POL_NUM	        INSTAL_NUM	AMOUNT	STATUS_CODE	STATUS_DESC	    OUT_PAYMENT_ID	INST_ID	    COLL_DATE	POLICY_NR	INSTALLMENT_ID
HGP205597566	113	        137.93	2	        Sent to Bank	3325642471	    44545724	10/NOV/18	277208	    44545724
------------------------------------------------------------------------------*/
select  
    pp.external_policy_number as pol_num
    ,ai.installment_number as instal_num
    ,apo.expected_amt as amount
    ,apo.status as status_code
    ,tpils.description as status_desc
    ,apod.out_payment_id
    ,ai.id as inst_id
    ,ai.collection_date as coll_date
    ,apo.*
from
ac_pmnt_interface_out apo
    join t_pmnt_interface_line_status tpils on tpils.id = apo.status
    inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
    inner join ac_installment ai on apo.installment_id = ai.id
    left outer join p_pol_header ph on ai.policy_header_id = ph.id
    left outer join p_policy pp on ph.active_policy_id = pp.id
where 1=1 
    and pp.external_policy_number = trim(:ext_policy_num)
    and ai.installment_number = trim(:instalment_num)

;


/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

START HERE IF YOU ALREADY HAVE THE OUT_PAYMENT_ID INFORMATION

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Search for the string: COMMA,DELIMITED,OUT_PAYMENT_IDS

Replace all instances of it with your OUT_PAYMENT_ID values, comma-delimted
(e.g. 3364461871,3364463588,3364467228,3364956470,3364957379,3364957884)

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

--FILE HEADER
select 
      '1RACAPI    ' as static_prefix
      ,TO_CHAR(sysdate,'YYYYMMDDHH24MI') as datetime_stamp
      ,'RACWA API and QB     ' as Client_Name
      ,LPAD(to_char(sysdate,'DDMMYYYY'),17,' ') as unique_file_id_1
      ,'.C' as unique_file_id_2
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,187,' ') as DD_CC_File_ID_and_filler
from dual
;

--BATCH HEADER
select 
      '3RAC Insurance QuickBatch      RACIIDIT  CC                  ' as static_prefix
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,189,' ') as DD_CC_File_ID_and_filler
from dual
;

--DETAILS
select 
      '5  00000000' as prefix
      ,RPAD(ccba.account_nr, 16, ' ')  as CREDIT_CARD_NUMBER  ,' ' as fill
      , LPAD((apo.expected_amt * 100), 10, '0') as expected_amount_no_dec
      ,'               ' as fill_1
            ,substr(
              CASE 
                WHEN upper(ccba.credit_card_holder_name) is not null THEN RPAD(ccba.credit_card_holder_name, 22, ' ')
                ELSE 'NO NAME ON SHIELD REC '
              END                                                           ,1, 22
              ) 
      AS CREDIT_CARD_HOLDER_NAME
      ,apod.out_payment_id
      ,'                                            ' as fill_2
             ,substr(
                    CASE 
                WHEN 1=1 THEN   '105 Do not honour                                               '
                ELSE                             '008 Honour with identification                                  '
              END                                                           ,1, 64
              ) 
       as bank_reponse
      ,substr(
              CASE 
                WHEN upper(ccba.bank_name)= 'VISA' THEN 'VI'
                WHEN upper(ccba.bank_name)= 'MASTERCARD' THEN 'MC'
                WHEN upper(ccba.bank_name) = 'AMEX' THEN 'AX'
                ELSE '?'
              END                                                           ,1, 2
              ) 
      AS Card_Type_Code                ,'                                                       ' as fill_3
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
           left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
      and apod.out_payment_id in (
                                  COMMA,DELIMITED,OUT_PAYMENT_IDS
                                    )
                                                                      
;

--BATCH FOOTER
select
      '7' as static_prefix
      ,substr(LPAD(
                    (
                    select count(*) as total_record_count
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
      and apod.out_payment_id in (
      								COMMA,DELIMITED,OUT_PAYMENT_IDS
                                  )
                    )
                    ,6,'0'),1,6) as total_record_count 
      ,substr(LPAD(
                    (
                    select sum(apo.expected_amt * 100) as expected_amount_no_dec
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
      and apod.out_payment_id in (
      								COMMA,DELIMITED,OUT_PAYMENT_IDS
                                  )
                    )
                    ,10,'0'),1,10) as sum_total_payments 
      ,'RACIIDIT  ' as static_company_code
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,223,' ') as DD_CC_File_ID_and_filler
from dual
;
--FILE FOOTER
select
      '9' as static_prefix
      ,'01' as batch_count 
      ,substr(LPAD(
                    (
                    select count(*) as total_record_count
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
      and apod.out_payment_id in (
      								COMMA,DELIMITED,OUT_PAYMENT_IDS
                                  )
                    )
                    ,8,'0'),1,8) as total_record_count 
      ,substr(LPAD(
                    (
                    select sum(apo.expected_amt * 100) as expected_amount_no_dec
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
      and apod.out_payment_id in (
      								COMMA,DELIMITED,OUT_PAYMENT_IDS
                                  )                    )
                    ,12,'0'),1,12) as sum_total_payments 
      ,'RACAPI    RACWA API and QB              ' as static_commun_client
      ,to_char(sysdate,'DDMMYYYY') as unique_file_id_1
      ,'.C' as unique_file_id_2
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,176,' ') as DD_CC_File_ID_and_filler
from dual
;

--File Name

/*
PURPOSE: Generate a syntactically correct file name for a Westpac Response file
with the following properties:
- contains records related to Direct Debit from Credit Cards
- does not clash with any existing records in the Shield database this is being
run for
- should not clash with any future files received from the actual Westpac test
service

COMMENTS: The sequence number logic here is an ugly hack that never quite did 
what it was intended to but remains as that has never made a difference and is 
strictly for non-production. It was written long enough ago that I don't recall
the details of why, would need to re-acquaint myself if it becomes necessary.
Troy Hall: 20180927
*/
select 
  'RACI_314295_DD_CC_RESP_' as static_prefix
  ,(
     select 
      substr
      (
        CASE 
          WHEN 
            (--find the lowest sequence number already existing in received files
            select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') 
            from sh_enhncd_ai_dtld_trans_hdr 
            where lower(file_name) like '%dd_cc_resp_%' --Direct Debit Credit Card
            ) > 100 --Compare with 100
          THEN 
            ( --Use the current lowest value minus 1 (so they iterate downwards)
            select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 
            from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%'
            )
          ELSE 200 --If not, just set it to 200, establishing a number > 100
        END ,1, 22
      )
     from dual
  ) as DD_CC_File_ID
  ,'_' as spacer
  ,TO_CHAR(sysdate,'YYYYMMDDHH24') as datetime_stamp
  ,'0099' as static_suffix
from 
  dual