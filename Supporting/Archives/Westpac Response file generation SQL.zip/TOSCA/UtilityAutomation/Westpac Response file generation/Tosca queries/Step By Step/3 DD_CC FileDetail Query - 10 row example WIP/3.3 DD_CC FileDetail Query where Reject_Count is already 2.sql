                                                 
                                                    select      
      '5  00000000' as prefix
      ,RPAD(ccba.account_nr, 16, ' ')  as CREDIT_CARD_NUMBER  ,' ' as fill
      , LPAD((apo.expected_amt * 100), 10, '0') as expected_amount_no_dec
      ,'               ' as fill_1
            ,substr(
              CASE 
                WHEN upper(ccba.credit_card_holder_name) is not null THEN RPAD(ccba.credit_card_holder_name, 22, ' ')
                ELSE 'NO NAME ON SHIELD REC '
              END                                                           ,1, 22
              ) 
      AS CREDIT_CARD_HOLDER_NAME
      ,apod.out_payment_id
      ,'                                            ' as fill_2
             ,substr(
                    CASE 
                WHEN rownum < (
                    select round(count(*) * 0.3) as first_thirty_percent 
                    from ac_pmnt_interface_out apo 
                        inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id 
                        inner join ac_installment ai on apo.installment_id = ai.id 
                        left outer join p_pol_header ph on ai.policy_header_id = ph.id
                        left outer join p_policy p on ph.active_policy_id = p.id
                        left outer join t_installment_status_type tist on tist.id = ai.installment_status
                        left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
                        left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
                        left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id 
                    where 1=1
                    	and apod.out_payment_id in (
                    			select 
                    				scor1.out_payment_id 
                    			from sh_collections_out_raci scor1 
                    				left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id
                    			where 1=1 
                    			and scor1.batch_id = 
							                        (
							                        select 
							                        min(scoh.batch_id) 
							                        from 
							                        sh_collections_out_header scoh  
							                        where 
							                        scoh.collection_method = 4 
							                        and scoh.processing_date between sysdate-34 and sysdate-1
							                        )  
            					and sheaidt.payment_id is null 
            					and scor1.collection_method = 4
            					and rownum < 101
                    								)
                              )   THEN   '105 Do not honour                                               '
                ELSE                             '008 Honour with identification                                  '
              END                                                           ,1, 64
              ) 
       as bank_reponse
      ,substr(
              CASE 
                WHEN upper(ccba.bank_name)= 'VISA' THEN 'VI'
                WHEN upper(ccba.bank_name)= 'MASTERCARD' THEN 'MC'
                WHEN upper(ccba.bank_name) = 'AMEX' THEN 'AX'
                ELSE '?'
              END                                                           ,1, 2
              ) 
      AS Card_Type_Code                ,'                                                       ' as fill_3
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
           left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
      and apod.out_payment_id in (
                    			select 
                    				scor1.out_payment_id 
                    			from sh_collections_out_raci scor1
                                    join ac_pmnt_out_details apod1                  on apod1.out_payment_id = scor1.out_payment_id
                                    join ac_installment ai1                         on ai1.id = apod1.installment_id
                    				left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.out_payment_id
                    			where 1=1 
                    			and scor1.batch_id = 
							                        (
							                        select 
							                        min(scoh.batch_id) 
							                        from 
							                        sh_collections_out_header scoh  
							                        where 
							                        scoh.collection_method = 4 
							                        and scoh.processing_date between sysdate-34 and sysdate
							                        )  
            					and sheaidt.payment_id is null 
            					and scor1.collection_method = 4
                                and ai1.reject_number = 2
                                and ai1.installment_status = 3
                                and ai1.original_collection_date between sysdate-100 and sysdate-31
                                and ai1.collection_date < sysdate+1
            					and rownum < 101
                    								)
                                                    