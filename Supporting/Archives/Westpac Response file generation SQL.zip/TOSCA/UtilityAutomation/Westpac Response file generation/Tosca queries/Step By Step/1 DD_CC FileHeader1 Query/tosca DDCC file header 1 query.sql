select 
      '1RACAPI    ' as static_prefix
      ,TO_CHAR(sysdate,'YYYYMMDDHH24MI') as datetime_stamp
      ,'RACWA API and QB     ' as Client_Name
      ,LPAD(to_char(sysdate,'DDMMYYYY'),17,' ') as unique_file_id_1
      ,'.C' as unique_file_id_2
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,187,' ') as DD_CC_File_ID_and_filler
from dual