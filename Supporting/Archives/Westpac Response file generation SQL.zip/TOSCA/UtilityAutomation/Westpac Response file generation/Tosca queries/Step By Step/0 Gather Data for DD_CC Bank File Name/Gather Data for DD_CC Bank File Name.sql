/*
PURPOSE: Generate a syntactically correct file name for a Westpac Response file
with the following properties:
- contains records related to Direct Debit from Credit Cards
- does not clash with any existing records in the Shield database this is being
run for
- should not clash with any future files received from the actual Westpac test
service

COMMENTS: The sequence number logic here is an ugly hack that never quite did 
what it was intended to but remains as that has never made a difference and is 
strictly for non-production. It was written long enough ago that I don't recall
the details of why, would need to re-acquaint myself if it becomes necessary.
Troy Hall: 20180927
*/
select 
  'RACI_314295_DD_CC_RESP_' as static_prefix
  ,(
     select 
      substr
      (
        CASE 
          WHEN 
            (--find the lowest sequence number already existing in received files
            select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') 
            from sh_enhncd_ai_dtld_trans_hdr 
            where lower(file_name) like '%dd_cc_resp_%' --Direct Debit Credit Card
            ) > 100 --Compare with 100
          THEN 
            ( --Use the current lowest value minus 1 (so they iterate downwards)
            select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 
            from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%'
            )
          ELSE 200 --If not, just set it to 200, establishing a number > 100
        END ,1, 22
      )
     from dual
  ) as DD_CC_File_ID
  ,'_' as spacer
  ,TO_CHAR(sysdate,'YYYYMMDDHH24') as datetime_stamp
  ,'0099' as static_suffix
from 
  dual