select 
      '3RAC Insurance QuickBatch      RACIIDIT  CC                  ' as static_prefix
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,189,' ') as DD_CC_File_ID_and_filler
from dual