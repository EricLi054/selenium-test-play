select
      '9' as static_prefix
      ,'01' as batch_count 
      ,substr(LPAD(
                    (
                    select count(*) as total_record_count
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
      and apod.out_payment_id in (
      								3051578570,3051905744,3051867348,3051871489,3051618178,3051498041,3051478540,3051607064,3051195119,3051105593,3051877856
                                  )
                    )
                    ,8,'0'),1,8) as total_record_count 
      ,substr(LPAD(
                    (
                    select sum(apo.expected_amt * 100) as expected_amount_no_dec
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
      and apod.out_payment_id in (
      								3051578570,3051905744,3051867348,3051871489,3051618178,3051498041,3051478540,3051607064,3051195119,3051105593,3051877856
                                  )                    )
                    ,12,'0'),1,12) as sum_total_payments 
      ,'RACAPI    RACWA API and QB              ' as static_commun_client
      ,to_char(sysdate,'DDMMYYYY') as unique_file_id_1
      ,'.C' as unique_file_id_2
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,176,' ') as DD_CC_File_ID_and_filler
from dual