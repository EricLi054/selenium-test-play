## DB Synonyms SQL
Tosca used to run jobs to provide DB synonyms for 8 tables; 5 of which were METADATA tables that supported faster test DB queries.

The METADATA related queries have since been retired as tests no longer rely on those tables, and they were costly to maintain.

The last 3 tables:
* SH_CTI_CALL_DETAILS_RACI
* C_CLAIM_CTI_TAGGING_RACI
* P_POLICY_CTI_TAGGING_RACI

are all being recorded here for posterity, as while these tables exist, there is no known link between them and current test activities.

### NOTES:
These SQL queries are all in their original Oracle SQL formats. They have not been ported to MSSQL and cannot be run as-is in Djandang Shield environments as MSSQL uses a `CREATE OR ALTER` variant.