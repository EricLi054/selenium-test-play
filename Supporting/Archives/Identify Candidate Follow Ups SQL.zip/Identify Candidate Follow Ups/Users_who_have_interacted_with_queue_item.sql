--Get users who have interacted with this Q_ITEM record - Particularly useful if trying to figure out what went wrong when things don't make sense
select 
    tu.name_of_user, 
    cn.first_name, 
    cn.name as surname, 
    qih.* 
from IDIT_PRD.q_item_history qih 
    join t_user tu on tu.userid = qih.update_user 
    join cn_contact cn on cn.id = tu.contact_id 
where 1=1
and qih.queue_item_id = 9773199
;