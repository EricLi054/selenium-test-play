--New Find FU for DD 3rd Rejection 
select * from t_queue where lower(queue_dsc) like '%financial%';
--GET Events based on Follow Up type (includes ee.claim_nr and q_item.id value)
select 	
--count(*) as count/*
--/*
  to_char(sysdate,'DD-MON-RR HH24:MI:SS') as query_runtime,
  ee.event_nr,
--  c.claim_number,
  p.external_policy_number,
--  substr(qi.remark,18,7) as ArnieJob_From_Remark,
  qi.id as qi_id,
  qi.insert_date as qi_insertdate,
  tu.name_of_user as assigned_to,
  tu1.name_of_user as last_updated_by,
  tqs.description as q_status,
--  tet.developer_desc as EVENT_DESC,
  TRC.DEFAULT_DESCRIPTION as EVENT_DSC_RES,
  tet1.developer_desc as FU_DESC,
  qi.original_start_handling_date,
  to_char(qi.due_date,'DD-MON-RR HH24:MI:SS') as qi_due_stamp,
  to_char(qi.next_handle_date,'DD-MON-RR HH24:MI:SS') as qi_next_handle_stamp,
	to_char(qi.status_date,'DD-MON-RR HH24:MI:SS') as qi_status_stamp,
  to_char(qi.update_date,'DD-MON-RR HH24:MI:SS') as qi_update_stamp,
	tq.queue_dsc,
    tq.queue_id,
  qi.remark as qi_remark_content,
  tu.userid as assigned_userid,
  qi.assign_company_tree as qi_assign_company_tree,
  qi.event_follow_up_id as qi_evnt_fu_id
  ,qi.was_viewed
  ,efu.follow_up_type as fu_type_code
  ,qi.update_user as update_userid
--  ,efu.*
-- Ends the comment sweep above out the start of this tag just beneath the count line it will stop here ----> */
from 
    p_policy p
    join e_event ee on ee.policy = p.id
  	join t_event_type tet on tet.event_type = ee.event_type 
  	join E_EVENT_FOLLOW_UP efu on efu.event_nr = ee.event_nr --normal Join when I want to limit to follow ups 
--    left outer join t_event_type tet1 on tet1.event_type = efu.follow_up_type --Left Outer Join if I want events even where they don't have an associated follow up (UNLIKELY NOW)
    join t_event_type tet1 on tet1.event_type = efu.follow_up_type --Normal join because I don't need events without follow ups
    left outer join t_resource_code trc on TRC.RESOURCE_CODE = tet.dsc_id --Encountered some event descriptions where t_event_type != t_resource_code
    left outer join q_item qi on qi.event_follow_up_id = efu.id 
    join t_queue tq on tq.queue_id = qi.queue_id
    join t_queue_status tqs on tqs.id = qi.status
    left outer join t_company_tree tct on tct.id = qi.assign_company_tree
    left outer join t_user tu on tu.userid = tct.user_id
    join t_user tu1 on tu1.userid = qi.update_user
--; 
where 1=1
--PLEASE NOTE: This was implemented to avoid false-positives when looking for for NULL "Remark" fields on early processes; you may need to provide a different go-live date to avoid false-positives regarding later proccesses
  and to_date(to_char(efu.insert_date,'dd/MON/yyyy'),'dd/MON/yyyy') > '17/AUG/17' --Limit FU due date because we don't want entries before the first Sapiens Release that included our changes to "Remark"

--  and qi.remark is null --Show me records where Q_ITEM.REMARK is empty (It should NEVER be empty for Claims FU's, but so far the Policy follow ups will be)

--  and efu.follow_up_type in (3000032,4000108,4000109,4000110,2001951,2001952)--Limit to the new follow ups ONLY (select * from t_event_type where event_type in (3000032,4000108,4000109,4000110,,2001951,2001952);)
and efu.follow_up_type in (2001951,2001952) --(RECOMMENDED) Return Both Direct debit 3rd Rejection - Future Paid instalment (--select * from t_event_type where lower(event_type_dsc) like '%future paid%';)
--and efu.follow_up_type in (2001951) -- Return only Direct debit 3rd Rejection - Future Paid instalment
--and efu.follow_up_type in (2001952) -- Return only Direct debit 3rd Rejection - Future Paid instalment follow up

  and tq.queue_id in (1001007,2000020) --Limit to either Finanical Underwriting queue
--  and tq.queue_id = 1001007	--Limit to just Financial Underwriter Workflow queue
--  and tq.queue_id = 2000020	--Limit to just Financial Underwriting Follow Up queue
--  and tq.queue_id = 4000003 --Limit to just Motor Assessing Automation queue
--  and tq.queue_id in (4000003,1001023) --Limit to either Motor Assessing queue
  and tu.name_of_user is null --Unassigned only

  and qi.due_date < sysdate+1 --Due date today or earlier
-- and qi.due_date between sysdate-60 and sysdate+100 --Alternative due date limit; we don't want entries from all time but might want some future-view
  and qi.status in (1,2,3,5,7) --Limit based on statuses (see below from t_queue_status.id values - suggest all new/open but not Error/Closed)
                                                          --1 New, 2 Open, 4 Closed, 3 Postponed, 7 Produced, 5	Processing, 6 Error
-- and qi.status = 4 --Show me closed records
 --Exclude Home policies (e.g. Quote-Close can be incorrectly created relating to Home policies by users grabbing the incorrect claim)

--  and qi.id in (9696122,9696954,9696126) --Limit to Certain Q_ITEM.ID values I identified from an earlier run of this script

--Legacy included from the older C_CLAIM query which could be useful if we start dealing with Policy FU that have remarks
--  and substr(qi.remark,18,7) in (2757413,2757522,2757546,2757548,2757550) --Find with a particular claim number in the "Remark" field easily by matching to only the 18th-24th characters in that field.
--  and qi.remark like 'Arnie job number 3%' --Alternative (also slower) way to find particular "Remark" values

--and p.external_policy_number in ('MGP317931946','MGP306665533','HGP302887058','MGP319328426','MGP318794377') --Return only for particular policy numbers

--and qi.update_user in (5002513,5002523,5002524,5002593,5002515) -- Return records last updated by these users (select t_user.name_of_user, t_user.* from t_user where userid in (5002513,5002523,5002524,5002593,5002515);)
--and qi.update_user not in (5002513,5002523,5002524,5002593,5002515)

--and qi.was_viewed = 1 --1 = already viewed by someone, 0 = never been kissed

--order by p.id,qi.iddesc --Group entries for the same policies together - may impact performance

order by tet1.developer_desc --Clump into types of Follow Ups (optional - SLIGHTLY faster without)
;


