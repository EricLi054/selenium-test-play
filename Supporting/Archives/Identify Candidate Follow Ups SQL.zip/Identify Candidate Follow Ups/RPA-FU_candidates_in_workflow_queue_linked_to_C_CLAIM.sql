--GET Events based on Follow Up type (includes ee.claim_nr and q_item.id value)
select 	
--count(*) as count
--/*
  to_char(sysdate,'DD-MON-RR HH24:MI:SS') as runtime,
  ee.event_nr,
  c.claim_number,
  p.external_policy_number,
  substr(qi.remark,18,7) as ArnieJob_From_Remark,
  qi.id as qi_id,
--  qi.insert_date as qi_insertdate, --not so useful
  tu.name_of_user as assigned_to,
  tu1.name_of_user as last_updated_by,
  tqs.description as q_status,
--  tet.developer_desc as EVENT_DESC,
  TRC.DEFAULT_DESCRIPTION as EVENT_DSC_RES,
  tet1.developer_desc as FU_DESC,
  qi.original_start_handling_date,
  to_char(qi.due_date,'DD-MON-RR HH24:MI:SS') as qi_due_stamp,
  to_char(qi.next_handle_date,'DD-MON-RR HH24:MI:SS') as qi_next_handle_stamp,
	to_char(qi.status_date,'DD-MON-RR HH24:MI:SS') as qi_status_stamp,
  to_char(qi.update_date,'DD-MON-RR HH24:MI:SS') as qi_update_stamp,
	tq.queue_dsc,
  qi.remark as qi_remark_content,
  tu.userid as assigned_userid,
  qi.assign_company_tree as qi_assign_company_tree,
  qi.event_follow_up_id as qi_evnt_fu_id
  ,qi.was_viewed
  ,efu.follow_up_type as fu_type_code
--  ,efu.*
-- Ends the comment sweep above out the start of this tag just beneath the count line it will stop here ----> */
from 
    c_claim c 
    join p_policy p on p.id = c.endorsment_id
    join e_event ee on ee.claim_nr = c.id
  	join t_event_type tet on tet.event_type = ee.event_type 
  	join E_EVENT_FOLLOW_UP efu on efu.event_nr = ee.event_nr --normal Join when I want to limit to follow ups 
    -- left outer join t_event_type tet1 on tet1.event_type = efu.follow_up_type --Left Outer Join if I want events even where they don't have an associated follow up
    join t_event_type tet1 on tet1.event_type = efu.follow_up_type --Normal join because I don't need events without follow ups
    left outer join t_resource_code trc on TRC.RESOURCE_CODE = tet.dsc_id --Encountered some event descriptions where t_event_type != t_resource_code - this should plug those gaps
    left outer join q_item qi on qi.event_follow_up_id = efu.id 
    join t_queue tq on tq.queue_id = qi.queue_id
    join t_queue_status tqs on tqs.id = qi.status
    left outer join t_company_tree tct on tct.id = qi.assign_company_tree
    left outer join t_user tu on tu.userid = tct.user_id
    join t_user tu1 on tu1.userid = qi.update_user

where 1=1
--PLEASE NOTE: This was implemented to avoid false-positives when looking for for NULL "Remark" fields on early processes; you may need to provide a different go-live date to avoid false-positives regarding later proccesses
 and to_date(to_char(efu.insert_date,'dd/MON/yyyy'),'dd/MON/yyyy') > '17/AUG/17' --Limit FU due date because we don't want entries before the first Sapiens Release that included our changes to "Remark"

--  and qi.remark is null --Show me records where Q_ITEM.REMARK is empty (It should NEVER be empty, that would be bad)

 and efu.follow_up_type in (3000032,4000108,4000109,4000110)--Limit to the new Claims follow ups ONLY (select * from t_event_type where event_type in (3000032,4000108,4000109,4000110);)
--  and efu.follow_up_type in (3000032) --Limit to Notify claimant - Repairs authorised (AKA: Quote Authorised) only
--  and efu.follow_up_type in (4000108) --Limit to Quote-Reminder only
--  and efu.follow_up_type in (4000108,4000109) --Limit to Quote-Reminder & Quote-Close
--  and efu.follow_up_type in (4000109) --Limit To Quote-Closed only

--  and efu.follow_up_type in (4000110) --Limit to Invoice-Reminder only
 and tq.queue_id = 4000003 --Limit to just Motor Assessing Automation queue
--  and tq.queue_id in (4000003,1001023) --Limit to either of the Motor Assessing queues
 and tu.name_of_user is null --Unassigned records only (at time of writing the bots shouldn't be looking at anything which is assigned to a user)

--and qi.assign_company_tree is not null --Records which ARE assigned to a user only.

 and qi.due_date < sysdate --Due date today or earlier
-- and qi.due_date between sysdate-60 and sysdate+100 --Alternative due date limit; we don't want entries from all time but might want some future-view
 and qi.status in (1,2,3,5,7) --Limit based on statuses (see below from t_queue_status.id values - suggest all new/open but not Error/Closed)
                                                          --1 New, 2 Open, 4 Closed, 3 Postponed, 7 Produced, 5	Processing, 6 Error
-- and qi.status = 4 --Show me closed records
 and p.external_policy_number not like 'H%' --Exclude Home policies (e.g. Quote-Close can be incorrectly created relating to Home policies by users grabbing the incorrect claim)
--  and qi.id in (9696122,9696954,9696126) --Limit to Certain Q_ITEM.ID values I identified from an earlier run of this script, for when you want to monitor their state.

--Search for comma-delimited claim numbers from VALID .csv output files (based on the Event tables)
-- and ee.claim_nr in (11344146,11335363,11315178,11346412,11345465,11343250,11345243,11345437,11341290,11344035,11342062,11328924,11345416,11345851,11338009,11346478,11345239,11340525,11345468,11333667,11338340,11325221,11345848,11345387,11345222,11336994,11333901)

--Search for comma-delimited claim numbers from VALID .csv output files (based on the Claims tables)
-- and c.claim_number in (21374810,21375057,21375087,21375089,21375092) 
-- and substr(qi.remark,18,7) in (2757413,2757522,2757546,2757548,2757550) --Find with a particular claim number in the "Remark" field easily by matching to only the 18th-24th characters in that field.
-- and qi.remark like 'Arnie job number 3%' --Alternative (also slower) way to find particular "Remark" values

-- and qi.remark = 'Arnie job number 2837257' --Match only if a single explicit value exists in "Remark"

-- and qi.was_viewed = 1 --1 = already viewed by someone, 0 = never been kissed

--order by c.id,qi.iddesc --Group entries for the same claims together, may impact performance
order by tet1.developer_desc --Clump into types of Follow Ups (optional - this is SLIGHTLY faster without)
;
