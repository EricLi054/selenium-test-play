--Fetch REJECT_NUMBER, OUT_PAYMENT_ID, POLICY NUMBER and INSTALLMENT_NUMBER
--Using any of the above as search term (recommend combining REJECT_NUMBER with POLICY_NUMBER at least)
select ai.reject_number , apod.out_payment_id, pp.external_policy_number, ai.installment_number
from 
ac_installment ai
inner join ac_pmnt_interface_out apo on ai.id = apo.installment_id
inner join ac_pmnt_out_details apod on apod.pmnt_interface_out_id = apo.id
inner join p_pol_header ph on ai.policy_header_id = ph.id
inner join p_policy pp on ph.active_policy_id = pp.id
where 1=1
AND apod.out_payment_id = :out_payment_id
--and pp.external_policy_number = :policy_number
--and ai.installment_number =: installment_number
--and ai.reject_number is NULL
--and ai.reject_number in (1,2)
;
