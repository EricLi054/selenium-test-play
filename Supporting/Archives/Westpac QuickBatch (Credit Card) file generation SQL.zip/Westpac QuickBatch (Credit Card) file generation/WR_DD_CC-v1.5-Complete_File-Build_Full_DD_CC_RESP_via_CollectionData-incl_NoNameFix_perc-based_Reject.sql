/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
| TITLE:    Generate entries for full size QuickBatch Response File with 9% rejection rate
| 
| FILE:     WR_DD_CC-v1.5-Complete_File-Build_Full_DD_CC_RESP_entries_using_Auto-Gathered_CollectionData-incl_NoNameFix_percentage_based_rejections.sql
| 
| UPDATED:  2017-06-27
|           
| VERSION:  1.5
|           
| PURPOSE:
|           Automatically fetch Credit Card records from the most recent Collections Export job (run as part of the Collections Export - Initiator job) 
|           and produce the detailed records for a DD_CC_RESP file from Westpac
|           This would usually be because we haven't tokenized an environment correctly/at all.
| 
| NOTES:
|            Search for the text --!!STEP!!-- to find each query in this file rather than having to scroll through it.
|            
|            PHASE 1: DATA GATHERING
|            After running each query below, select any field in the returned data and press CTRL+A to Select All. (NB: When this is done for the Detailed Payment Records 
|            there will be a delay while SQL developer completes the full fetch.) 
|            Copy the selected records and paste them into an empty Notepad++ document, then press Enter to move to a new line ready for the data from the next query.
|            NB: Entries produced should ALWAYS be copied directly from the Query Result pane in SQL Developer and pasted into Notepad++.
|            
|            PHASE 2: FILE CLEAN-UP
|            Once all queries have been run and pasted into Notepad++, we run a Find/Replace REGEX to remove all TABS. I have a Macro for Notepad++ to 
|            strip out the tabs with 2 clicks (3 if you include OK on the success dialogue), or by pressing CTRL+SHIFT+DELETE. 
|            
|            If you prefer you can set the following in the 
|            Replace tab of the Find/Replace window in Notepad++:
|            
|            * Find what: \t
|            * Replace with:
|            * Wrap around = True
|            * Search Mode = Regular expression
|            
|            This file will process responses for all records from the most recent outbound Credit Card request file, with the first 9% of those records returned as rejections.
|            This is a rough equivalent to the percentage of rejections in the average QuickBatch file received in production as calculated at the start of 2017
|            from the production data I had available.
|            
|            Finally you will need to cut the final line of the file and save the file with that file-name, deleting the line from existence (final line of the file 
|            should begin with "9"). Ideally you will need to navigate to the file in Windows Explorer and rename it there, removing the ".txt" extension at the end
|            and selecting "Yes" on the warning prompt about changing the file extension.
|            
|            Your file is now ready for procesing via the Westpac ..\inbound\ready\ folder for your test environment.
|            
|            
| 
| TODO:
| DONE! -   Fixed issue with File Name Sequence Number generation not matching the behaviour for the rest of the file generation process and returning Sequence # 200 at all times.
| DONE! -   Fixed issue with & characters being picked up by sql developer despite being in the comments.
| DONE! -   Fixed issue with Time-stamp where syntax was returning YearMonthDay24HourMonth instead of YearMonthDay24HourMinute
| DONE! -   Automate the selection of a percentage of the file entries for Payment Rejection entries of a spread of different Rejection messages rather than a static number of entries.
| DONE! -   Incorporate Sum Total of entries in file.
| DONE! -   Provide File Name Generation
| DONE! -   Automate selection of the Unique Batch Identifier which features in all four Header/Footer records WITHOUT getting in the way of other files.
|           This is made more difficult by not being able to predict what references will be present, but seems that if we start with a CASE that checks for
|           a value below any production file, and adds that value if not present or uses minimum value-1 if it is present (e.g. along the lines of the following but 
|           with proper conversion to number for the value) so we can use values which will not clash with future files provided by ESB/Westpac. We will also require a check
|           to be sure the value arrived at does not already exist.
|
|
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
|  RELATED QUERIES
| 
| 
| --Peek at the current EXISTING minimum value of DD_CC files in system
| select min(substr(file_name,23,6)) DD_CC_File_ID from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp%' ;
| --alternatively
| --select file_name from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp%' order by file_name asc;
| -------------------------------------------------------------------------------------------------
| Find the unique value for the NEXT DD_CC file that won't match files coming from Westpac.
| 
| This starts at 200 and reduces by 1 every time a file is produced this way. 
| I have no idea how this will impact Shield if you create > 100 DD_CC files between refreshes from Production.
| 
| select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1  from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp%';
| 
| 
| 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/


--!!STEP!!--1
--Generate File Control Header Record (251 characters long)
--e.g. "1RACAPI    201702090948RACWA API and QB              09022017.C8600                                                                                                                                                                                       "

select 
      '1RACAPI    ' as static_prefix
      ,TO_CHAR(sysdate,'YYYYMMDDHH24MI') as datetime_stamp
      ,'RACWA API and QB     ' as Client_Name
      ,LPAD(to_char(sysdate,'DDMMYYYY'),17,' ') as unique_file_id_1
      ,'.C' as unique_file_id_2
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,187,' ') as DD_CC_File_ID_and_filler
from dual
;

--!!STEP!!--2
--Generate Batch Control Header Record
--e.g. "3RAC Insurance QuickBatch      RACIIDIT  CC                  8600                                                                                                                                                                                         "
select 
      '3RAC Insurance QuickBatch      RACIIDIT  CC                  ' as static_prefix
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,189,' ') as DD_CC_File_ID_and_filler
from dual
;

--!!STEP!!--3
--Generate ALL Detailed Payment Records for Credit Cards from the most recent Collections job (251 characters long)
select 
      '5  00000000' as prefix
      ,RPAD(ccba.account_nr, 16, ' ') --This value must have RPAD as any AMEX card will only be 15 characters and throw the flat file record length out.
      ,' ' as fill
      , LPAD((apo.expected_amt * 100), 10, '0') as expected_amount_no_dec
      ,'               ' as fill
          /*
          The following section was added to allow for records existing in Shield where we have a NULL value in ccba.credit_card_holder_name,
          ignoring the bad data and populating the name with 'NO NAME ON SHIELD REC ' so it stands out if you're looking over the file.
          Obviously this must be altered or these records amended if you are trying to test functionality around the ESB/Shield accepting a NULL name!
          */
            ,substr(
              CASE 
                WHEN upper(ccba.credit_card_holder_name) is not null THEN RPAD(ccba.credit_card_holder_name, 22, ' ')
                ELSE 'NO NAME ON SHIELD REC '
              END                                                           ,1, 22
              ) 
      AS CREDIT_CARD_HOLDER_NAME
      ,apod.out_payment_id
      ,'                                            ' as fill
            /*
            The following section was added to identify roughly the first 9% of the entries returned for the file to be marked as failures 
            with the remainder marked as success. We aim to avoid creating an unusual number of Payment Rejections which
            may cause Shield to struggle - especially once the Cancellation for Unpaid DD policies job comes into play.
            Kyle Green tested up to 2000 rejections in a single file when trying to check handling of volume. Please note this may not
            scale for extremely large files, i.e. the largest DD_CC Response file we've ever recieved from Westpac had 47547 entries 
            (which this would produce around 4279 Rejections for).
            
            There are 9 different types of rejection messages built into this process at roughly 1% per rejection message.
            
            !!!!PLEASE NOTE!!!!
            When using a query like this which automatically fetches payment_id values we haven't already got rejections for,
            any of the 960 entries that don't get marked as Rejected could turn up in this query again. This won't cause any 
            FUNCTIONAL issue but does mean that 3 runs does not mean you've generated files for all records in a 3000-record batch. 
            */
            ,substr(
                    CASE 
                WHEN rownum < (
                                select round(count(*) * 0.01) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                              )   THEN   '105 Do not honour                                               '
                WHEN rownum between (--0.02 (between 1 and 2)
                                select round(count(*) * 0.01) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                                ) 
                                and (
                                              select round(count(*) * 0.02) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                              )  THEN   '101 Refer to card issuer                                        '
                WHEN rownum between ( --0.03 (between 2 and 3)
                                select round(count(*) * 0.02) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                                ) 
                                and (
                                              select round(count(*) * 0.03) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                              )  THEN   '142 No universal account                                        '
                WHEN rownum between ( --0.04 (between 3 and 4)
                                select round(count(*) * 0.03) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                                ) 
                                and (
                                              select round(count(*) * 0.04) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                              )  THEN   '104 Pick-up card                                                '
                WHEN rownum between ( --0.05 (between 4 and 5)
                                select round(count(*) * 0.04) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                                ) 
                                and (
                                              select round(count(*) * 0.05) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                              )  THEN   '154 Expired card                                                '
                WHEN rownum between ( --0.06 (between 5 and 6)
                                select round(count(*) * 0.05) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                                ) 
                                and (
                                              select round(count(*) * 0.06) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                              )  THEN   '191 Issuer or switch is inoperative                             '
                WHEN rownum between ( --0.07 (between 6 and 7)
                                select round(count(*) * 0.06) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                                ) 
                                and (
                                              select round(count(*) * 0.07) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                              )  THEN   '162 Restricted card                                             '
                WHEN rownum between ( --0.08 (between 7 and 8)
                                select round(count(*) * 0.07) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                                ) 
                                and (
                                              select round(count(*) * 0.08) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                              )  THEN   '151 Not sufficient funds                                        '
                WHEN rownum between ( --0.09 (between 8 and 9)
                                select round(count(*) * 0.08) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                                ) 
                                and (
                                              select round(count(*) * 0.09) as first_percent from      ac_pmnt_interface_out apo      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id      inner join ac_installment ai on apo.installment_id = ai.id      left outer join p_pol_header ph on ai.policy_header_id = ph.id      left outer join p_policy p on ph.active_policy_id = p.id      left outer join t_installment_status_type tist on tist.id = ai.installment_status      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id where 1=1       and apod.out_payment_id in (                                  select                                     scor1.out_payment_id                                   from                                     sh_collections_out_raci scor1                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id                                   where 1=1                                    and scor1.batch_id = (                                        select                                           max(scor2.batch_id)                                         from                                           sh_collections_out_raci scor2                                        where                                           scor2.collection_method = 4                                                         )                                    and sheaidt.payment_id is null                                     and scor1.collection_method = 4)
                              )  THEN   '143 Stolen card, pick up                                        '
                ELSE                             '008 Honour with identification                                  '
              END                                                           ,1, 64
              ) 
       as bank_reponse
      ,substr(
              CASE 
                WHEN upper(ccba.bank_name)= 'VISA' THEN 'VI'
                WHEN upper(ccba.bank_name)= 'MASTERCARD' THEN 'MC'
                WHEN upper(ccba.bank_name) = 'AMEX' THEN 'AX'
                ELSE '?'
              END                                                           ,1, 2
              ) 
      AS Card_Type_Code          --TODO? Could have better error logic, as it is if there's not an exepected bank_name value then the '?' which the ESB will refuse to load.
      ,'                                                       ' as fill
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     -- inner join ac_installment_details aid on aid.id = ai.id
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
    /*
    Instead of copying up to 1000 comma-delimited OUT_PAYMENT_ID values from the Outbound or Inbound files exchanged with Westpac,
    this fetches the first 1000 references from the outbound file that we don't already have in our inbound tables.
    */
      and apod.out_payment_id in (
                                  select 
                                    scor1.out_payment_id --Actual PAYMENT_ID FOR CC
--                                    ,scor1.pmnt_out_id --Not to be confused for the actual Payment ID we want to use - documenting this as it could trip you up if re-purposing
--                                    ,scor1.batch_id --diagnostic only
--                                    ,scor1.collection_method --diagnostic only
--                                    ,sheaidt.payment_id --diagnostic only
--                                    ,scor1.*
                                  from 
                                    sh_collections_out_raci scor1
                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id --apod.out_payment_id
                                  where 1=1
                                    and scor1.batch_id = (
                                        select 
                                          max(scor2.batch_id) 
                                        from 
                                          sh_collections_out_raci scor2
                                        where 
                                          scor2.collection_method = 4 --Credit Card
                                                        )
                                    and sheaidt.payment_id is null
                                    and scor1.collection_method = 4 
                                    --and rownum < 1001 --diagnostic only
                                  )

;

--FOOTER ENTRIES FOR FILE BOTH INCLUDE THE SUM TOTAL OF THE DETAILED PAYMENT RECORDS RETURNED
--!!!!!!!!!!!!!!!!!!!WARNING!!!!!!!!!!!!!!!!!!!
-- THIS HAS PROVEN TO RETURN THE SAME RECORDS
-- AS THE DETAILED RECORD QUERY ABOVE SO FAR
-- 100% OF THE TIME BUT IF IT EVER RETURNS OTHERS
-- THE FILE WILL FAIL. FOR THIS REASON RUN THESE 
-- IMMEDATELY AFTER THE DETAILED RECORDS QUERY IS RUN.
--!!!!!!!!!!!!!!!!!!!WARNING!!!!!!!!!!!!!!!!!!!


	  
--!!STEP!!--4
--Create Batch Control Footer Record (251 characters long)
--e.g. "70010000006131546RACIIDIT  8600                                                                                                                                                                                                                           "
select
      '7' as static_prefix
      ,substr(LPAD(
                    (
                    select count(*) as total_record_count
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     -- inner join ac_installment_details aid on aid.id = ai.id
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
    /*
    Instead of copying up to 1000 comma-delimited OUT_PAYMENT_ID values from the Outbound or Inbound files exchanged with Westpac,
    this fetches the first 1000 references from the outbound file that we don't already have in our inbound tables.
    */
      and apod.out_payment_id in (
                                  select 
                                    scor1.out_payment_id --Actual PAYMENT_ID FOR CC
--                                    ,scor1.pmnt_out_id --Not to be confused for the actual Payment ID we want to use - documenting this as it could trip you up if re-purposing
--                                    ,scor1.batch_id --diagnostic only
--                                    ,scor1.collection_method --diagnostic only
--                                    ,sheaidt.payment_id --diagnostic only
--                                    ,scor1.*
                                  from 
                                    sh_collections_out_raci scor1
                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id --apod.out_payment_id
                                  where 1=1
                                    and scor1.batch_id = (
                                        select 
                                          max(scor2.batch_id) 
                                        from 
                                          sh_collections_out_raci scor2
                                        where 
                                          scor2.collection_method = 4 --Credit Card
                                                        )
                                    and sheaidt.payment_id is null --Don't get a record where an existing sh_enhncd_ai_dtld_trans record already exists for that PAYMENT_ID (Which indicates we have already had a rejection returned for that payment)
                                    and scor1.collection_method = 4 
                                    --and rownum < 1001 --diagnostic only
                                  )
                    )
                    ,6,'0'),1,6) as total_record_count --usually 1000?
      ,substr(LPAD(
                    (
                    select sum(apo.expected_amt * 100) as expected_amount_no_dec
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     -- inner join ac_installment_details aid on aid.id = ai.id
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
    /*
    Instead of copying up to 1000 comma-delimited OUT_PAYMENT_ID values from the Outbound or Inbound files exchanged with Westpac,
    this fetches the first 1000 references from the outbound file that we don't already have in our inbound tables.
    */
      and apod.out_payment_id in (
                                  select 
                                    scor1.out_payment_id --Actual PAYMENT_ID FOR CC
--                                    ,scor1.pmnt_out_id --Not to be confused for the actual Payment ID we want to use - documenting this as it could trip you up if re-purposing
--                                    ,scor1.batch_id --diagnostic only
--                                    ,scor1.collection_method --diagnostic only
--                                    ,sheaidt.payment_id --diagnostic only
--                                    ,scor1.*
                                  from 
                                    sh_collections_out_raci scor1
                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id --apod.out_payment_id
                                  where 1=1
                                    and scor1.batch_id = (
                                        select 
                                          max(scor2.batch_id) 
                                        from 
                                          sh_collections_out_raci scor2
                                        where 
                                          scor2.collection_method = 4 --Credit Card
                                                        )
                                    and sheaidt.payment_id is null --Don't get a record where an existing sh_enhncd_ai_dtld_trans record already exists for that PAYMENT_ID (Which indicates we have already had a rejection returned for that payment)
                                    and scor1.collection_method = 4 
                                    --and rownum < 1001 --diagnostic only
                                  )
                    )
                    ,10,'0'),1,10) as sum_total_payments 
      ,'RACIIDIT  ' as static_company_code
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,223,' ') as DD_CC_File_ID_and_filler
from dual
;

--!!STEP!!--5
--Create File Control Footer Record (251 characters long)
--e.g. "90100001000000006131546RACAPI    RACWA API and QB              09022017.C8600                                                                                                                                                                             "
select
      '9' as static_prefix
      ,'01' as batch_count --should be static - we expect 1:1 file:batch 
      ,substr(LPAD(
                    (
                    select count(*) as total_record_count
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     -- inner join ac_installment_details aid on aid.id = ai.id
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
    /*
    Instead of copying up to 1000 comma-delimited OUT_PAYMENT_ID values from the Outbound or Inbound files exchanged with Westpac,
    this fetches the first 1000 references from the outbound file that we don't already have in our inbound tables.
    */
      and apod.out_payment_id in (
                                  select 
                                    scor1.out_payment_id --Actual PAYMENT_ID FOR CC
--                                    ,scor1.pmnt_out_id --Not to be confused for the actual Payment ID we want to use - documenting this as it could trip you up if re-purposing
--                                    ,scor1.batch_id --diagnostic only
--                                    ,scor1.collection_method --diagnostic only
--                                    ,sheaidt.payment_id --diagnostic only
--                                    ,scor1.*
                                  from 
                                    sh_collections_out_raci scor1
                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id --apod.out_payment_id
                                  where 1=1
                                    and scor1.batch_id = (
                                        select 
                                          max(scor2.batch_id) 
                                        from 
                                          sh_collections_out_raci scor2
                                        where 
                                          scor2.collection_method = 4 --Credit Card
                                                        )
                                    and sheaidt.payment_id is null --Don't get a record where an existing sh_enhncd_ai_dtld_trans record already exists for that PAYMENT_ID (Which indicates we have already had a rejection returned for that payment)
                                    and scor1.collection_method = 4 
                                    --and rownum < 1001 --diagnostic only
                                  )
                    )
                    ,8,'0'),1,8) as total_record_count --usually 1000?
      ,substr(LPAD(
                    (
                    select sum(apo.expected_amt * 100) as expected_amount_no_dec
from
      ac_pmnt_interface_out apo
      inner join ac_pmnt_out_details apod on apo.id = apod.pmnt_interface_out_id
      inner join ac_installment ai on apo.installment_id = ai.id
     -- inner join ac_installment_details aid on aid.id = ai.id
      left outer join p_pol_header ph on ai.policy_header_id = ph.id
      left outer join p_policy p on ph.active_policy_id = p.id
      left outer join t_installment_status_type tist on tist.id = ai.installment_status
      left outer join t_pmnt_interface_line_status tpils on tpils.id = apo.status
      left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = apod.out_payment_id
      left outer join cn_contact_bank_account ccba on ccba.id = ai.contact_bank_account_id
where 1=1 
    /*
    Instead of copying up to 1000 comma-delimited OUT_PAYMENT_ID values from the Outbound or Inbound files exchanged with Westpac,
    this fetches the first 1000 references from the outbound file that we don't already have in our inbound tables.
    */
      and apod.out_payment_id in (
                                  select 
                                    scor1.out_payment_id --Actual PAYMENT_ID FOR CC
--                                    ,scor1.pmnt_out_id --Not to be confused for the actual Payment ID we want to use - documenting this as it could trip you up if re-purposing
--                                    ,scor1.batch_id --diagnostic only
--                                    ,scor1.collection_method --diagnostic only
--                                    ,sheaidt.payment_id --diagnostic only
--                                    ,scor1.*
                                  from 
                                    sh_collections_out_raci scor1
                                    left outer join sh_enhncd_ai_dtld_trans sheaidt on sheaidt.payment_id = scor1.pmnt_out_id --apod.out_payment_id
                                  where 1=1
                                    and scor1.batch_id = (
                                        select 
                                          max(scor2.batch_id) 
                                        from 
                                          sh_collections_out_raci scor2
                                        where 
                                          scor2.collection_method = 4 --Credit Card
                                                        )
                                    and sheaidt.payment_id is null --Don't get a record where an existing sh_enhncd_ai_dtld_trans record already exists for that PAYMENT_ID (Which indicates we have already had a rejection returned for that payment)
                                    and scor1.collection_method = 4 
                                    --and rownum < 1001 --diagnostic only
                                  )
                    )
                    ,12,'0'),1,12) as sum_total_payments 
      ,'RACAPI    RACWA API and QB              ' as static_commun_client
      ,to_char(sysdate,'DDMMYYYY') as unique_file_id_1
      ,'.C' as unique_file_id_2
      ,RPAD(
              (
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
                from dual
              )
              ,177,' ') as DD_CC_File_ID_and_filler
from dual
;


--!!STEP!!--6
--Generate File Name (e.g. RACI_314295_DD_CC_RESP_200_2017021610020410) - Note: There *should* be no file extension however if you accidentally leave .txt in place the ESB will tolerate that 
select 
      'RACI_314295_DD_CC_RESP_' as static_prefix
      ,(
               select substr(
                              CASE 
                                WHEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '') from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%') > 100 THEN (select REGEXP_REPLACE(min(substr(file_name,23,4)), '[^0-9]+', '')-1 from sh_enhncd_ai_dtld_trans_hdr where lower(file_name) like '%dd_cc_resp_%')
                                ELSE 200
                              END                                                           ,1, 22
                            )
               from dual
              
              
            ) as DD_CC_File_ID
        ,'_' as spacer
        ,TO_CHAR(sysdate,'YYYYMMDDHH24MI') as datetime_stamp
        ,'99' as static_suffix
        from dual
;