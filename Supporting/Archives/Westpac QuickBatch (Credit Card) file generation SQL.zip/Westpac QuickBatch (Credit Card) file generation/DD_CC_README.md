# QuickBatch (Direct Debit via Credit Card) Response File Generator

## Why?

If you don't tokenize a test environment, the responses from the Westpac test environment service return a ```1No No Account Registered``` response for every record. This makes it fail basic verification checks the ESB carries out when attempting to load a file into Shield, and so it cannot be processed.

This query generates all of the components of a file based on the Collections job outputs, with a 9% rejection rate (roughly the average for these files in Production last I checked) and appropriate response codes including the correct Credit Card type (AMEX, MasterCard or VISA) and filename. It does so in such a way as to never clash with a file received from Production or the Westpac test environment service.

Estimated repeated uses without having to refresh the test environment data are around 200.

## How?

- Run each query in sequence, saving all results to an empty file. 
- Once all parts are present in the file, remove all tabs via REGEX (```\t```) or use the macro for Notepad++ on the [wiki article](http://racisp.rac.com.au/BusSys/Projects/Testing/Wiki Pages/SIT_Testing_Team_SQL_Tool_for_QuickBatch_file_creation_without_Westpac.aspx).
- Cut the filename from the final line of the file and save the file with that name.

The wiki article mentioned above contains more information and detailed instructions.